---
name: Question
about: Ask a question about use, need help
---

#### Make sure
- [ ] Upgrade the latest [release](https://github.com/fluid-dev/hexo-theme-fluid/releases)
- [ ] No solution found in [documentations](https://hexo.fluid-dev.com/docs/en/)

#### Describe the question
<!-- A clear and concise description of what the question is. -->
